# Liste des choses à faire:

## Todolist brute:
- home page: nav bar, lien vers les autres pages, afficher le calendrier de la semaine 
- About us page : présentation des membres + des fonctionalités du site.
- page de licence
- Page contact : renvoie sur le mail d'un membre du groupe 
- un calendrier avec le évènements sur le mois et la semaine // 60 jours mois actuel + mois a venir.
- code couleur pour chaque association et type d'event( ouvert à tous/pas ouvert/soirée, etc..)
- un petit espace qui liste toutes les associations + petite présentation rapide + lien vers leurs réseaux sociaux // facultatif peut être pas le temps
- possiblité de selectionner l'évènement pour qu'il puisse s'afficher sur notre calendrier perso ? // complexe (on est meme pas sencé avoir de backend)
- 

## Todolist finale: 